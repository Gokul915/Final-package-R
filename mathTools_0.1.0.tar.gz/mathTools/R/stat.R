#' Compute Statistical Summaries
#'
#' This function calculates statistical summaries (mean, median, standard deviation, and range)
#' for a numeric vector.
#'
#' @param x A numeric vector.
#' @param na.rm Logical, whether to remove missing values (default is TRUE).
#'
#' @return A list containing the mean, median, standard deviation, and range of the input vector.
#' @examples
#' compute_statistics(c(1, 2, 3, 4, 5))
#' compute_statistics(c(NA, 2, 3, 4, 5), na.rm = TRUE)
#' @export
compute_statistics <- function(x, na.rm = TRUE) {
  if (!is.numeric(x)) {
    stop("Input must be a numeric vector.")
  }

  if (na.rm) {
    x <- x[!is.na(x)]
  }

  result <- list(
    mean = mean(x, na.rm = na.rm),
    median = median(x, na.rm = na.rm),
    std_dev = sd(x, na.rm = na.rm),
    range = range(x, na.rm = na.rm)
  )

  return(result)
}
